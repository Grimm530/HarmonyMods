using System;
using HarmonyLib;

namespace TruePVE.Patches;

[HarmonyPatch(typeof(BaseCombatEntity), "Hurt", new Type[] { typeof(HitInfo) })]
[HarmonyPriority(Priority.First)]
public static class BaseCombatEntity_Hurt_PvE_Deployable_Patch
{
	[HarmonyPrefix]
	public static bool Prefix(BaseCombatEntity __instance, HitInfo info)
	{
		if (!PvEDamageHelpers.ShouldBlockPlayerDeployableDamage(__instance, info))
		{
			return true;
		}
		info.damageTypes?.Clear();
		return false;
	}
}
