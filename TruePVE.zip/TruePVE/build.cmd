@echo off
setlocal
set "ROOT=%~dp0"
set "PROJECT=%ROOT%TruePVE.csproj"

echo Building TruePVE...
dotnet build "%PROJECT%" -c Release
if errorlevel 1 (
  echo Build failed! Check errors above.
  exit /b 1
)

set "HARMONYMODS=C:\SVR1\HarmonyMods"
if not exist "%HARMONYMODS%" mkdir "%HARMONYMODS%"

set "DLL=%ROOT%bin\Release\net48\TruePVE.dll"
if not exist "%DLL%" set "DLL=%ROOT%bin\Release\TruePVE.dll"

if not exist "%DLL%" (
  echo Built DLL not found at expected path.
  exit /b 1
)

copy /Y "%DLL%" "%HARMONYMODS%\TruePVE.dll" >nul
echo.
echo Build successful! TruePVE.dll copied to %HARMONYMODS%\TruePVE.dll
echo Load with: harmony.load TruePVE
exit /b 0
