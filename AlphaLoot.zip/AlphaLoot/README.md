# AlphaLoot Harmony Mod

Harmony-based replacement for the AlphaLoot Oxide plugin. Patches loot spawn methods directly to eliminate Oxide hook overhead (reflection, plugin iteration). Uses the same config and data format as AlphaLoot for drop-in compatibility.

---

## 1) Mod Identity

| Attribute | Value |
|-----------|-------|
| **Mod name** | AlphaLoot |
| **Type** | Harmony mod (IHarmonyModHooks) |
| **Purpose** | Replace Oxide AlphaLoot with low-overhead Harmony patches for loot table control |

**Primary responsibilities:**
- Override loot spawning for containers, Bradley/Heli crates, NPC corpses, and gift boxes (unwrap)
- Apply custom loot profiles from JSON config
- Provide admin commands: `al.additems`, `al.search`, `al.repopulateall`
- Auto-generate vanilla loot profiles when missing; optional auto-updater for new game items

**Key feature flags / modes:**
- `OverrideFancyDrop` – when true, supply drops use AlphaLoot `supply_drop` profile instead of vanilla/FancyDrop
- `AutoUpdate` – when true, merges new items from ItemManager into default containers on load

---

## 2) Runtime Topology (Architecture Overview)

| Component | Stores | Invariants |
|-----------|--------|------------|
| `AlphaLootMod.Instance` | Singleton; `_config`, `_storedData`, `_heliData`, `_bradleyData` | Set on `OnLoaded`, nulled on `OnUnloaded` |
| `AlphaLootContext` | Static: `Config`, `WeightedSkinIds`, `ImportedSkinIds` | Must be set before any populate; cleared on unload |
| `_storedData` | Main loot profiles (containers, NPCs, unwraps) | Loaded from `ProfileName.json` |
| `_heliData` | Heli crate profiles | Loaded from `HeliProfileName.json` |
| `_bradleyData` | Bradley crate profiles | Loaded from `BradleyProfileName.json` |

**State flow:**
- Config loaded from `HarmonyConfig/AlphaLoot.json` (or `oxide/config/` if Harmony path missing)
- Data loaded from `HarmonyConfig/AlphaLoot/LootProfiles/*.json` (or `oxide/data/AlphaLoot/`)
- Skin data from `item_skin_ids.json`

**Dependencies:** `Rust.Harmony`, `0Harmony`, `Assembly-CSharp`, `Newtonsoft.Json`

---

## 3) Persistent Data Model

### `StoredData`
- **Purpose:** Loot profiles per container/NPC type
- **Key fields:**
  - `loot_advanced` / `loot_simple` – container profiles (ShortPrefabName → profile)
  - `npcs_advanced` / `npcs_simple` – NPC corpse profiles (ShortPrefabName → profile)
  - `custom_advanced` / `custom_simple` – custom/event loot profiles
  - `npc_loadouts` – NPC shortname → loadout name list
- **Keys:** Container/NPC shortname (case-insensitive)
- **Storage:** `HarmonyConfig/AlphaLoot/LootProfiles/<ProfileName>.json`
- **Lifecycle:** Load on `OnLoaded`; Save via `AlphaLootTools.SaveData()` after AddItems or AutoUpdate

### Profile types
- `AdvancedLootContainerProfile` / `SimpleLootContainerProfile` – containers
- `AdvancedNPCLootProfile` / `SimpleNPCLootProfile` – NPC corpses
- `AdvancedCustomLootProfile` / `SimpleCustomLootProfile` – custom spawns

### `AlphaLootConfig`
- **Storage:** `HarmonyConfig/AlphaLoot.json` or `oxide/config/AlphaLoot.json`
- **Not hot-reloadable** – config read only on load

---

## 4) Configuration Schema (CONDENSED)

| Field | Type | Default | Behavioral impact |
|-------|------|---------|-------------------|
| `ProfileName` | string | `"default_loottable"` | Main loot profile filename |
| `HeliProfileName` | string | `"default_heli_loottable"` | Heli crate profile |
| `BradleyProfileName` | string | `"default_bradley_loottable"` | Bradley crate profile |
| `BradleyCrates` | int | -1 | Crates per Bradley (-1 = vanilla) |
| `HelicopterCrates` | int | -1 | Crates per Heli (-1 = vanilla) |
| `GlobalMultiplier` | float | 1f | Multiply all loot amounts |
| `MultiplyUnstackable` | bool | false | Apply multipliers to unstackable items |
| `ContainerOverrides` | Dict<string,string> | {} | Map container shortname → override profile |
| `IgnoreSkinsFor` | HashSet<string> | {} | Item shortnames that skip random skins |
| `OverrideFancyDrop` | bool | false | Supply drops use `supply_drop` profile |
| `AutoUpdate` | bool | false | Merge new items into loot tables on load |
| `DebugSupplyDrops` | bool | false | Log supply drop contents to console |

---

## 5) Permissions & Authorization

| Access | Who | Where enforced |
|--------|-----|----------------|
| `al.additems` | Admin only | `CanUseCommand()` – checks `arg.Player().IsAdmin` |
| `al.search` | Admin only | Same |
| `al.repopulateall` | Admin only | Same |

No Oxide permissions; admin status required for console commands. No player-facing chat commands (use `AlphaLootCommands.cs` Oxide plugin for `/aloot`, LootCycler).

---

## 6) Harmony Patches & Event Handling

| Patch | Target | Behavior | Side effects |
|-------|--------|----------|--------------|
| `LootContainer_SpawnLoot_Patch` | `LootContainer.SpawnLoot` | Prefix: if profile found and enabled, clear inventory and populate from profile; return `false` to skip vanilla | Inventory modify, optional `Invoke(SpawnLoot, delay)` for refresh |
| `BradleyAPC_ServerInit_Patch` | `BradleyAPC.ServerInit` | Postfix: set `maxCratesToSpawn` from config | None |
| `PatrolHelicopter_ServerInit_Patch` | `PatrolHelicopter.ServerInit` | Postfix: set `maxCratesToSpawn` from config | None |
| `HumanNPC_ApplyLoot_Patch` | `HumanNPC.ApplyLoot` | Prefix: populate corpse from NPC profile; return `false` to skip vanilla | Corpse container modify |
| `ScarecrowNPC_ApplyLoot_Patch` | `ScarecrowNPC.ApplyLoot` | Same as HumanNPC | Corpse container modify |
| `ItemModUnwrap_ServerCommand_Patch` | `ItemModUnwrap.ServerCommand` | Prefix: if unwrap profile exists, populate player inventory and consume item; return `false` to skip vanilla | Item consume, inventory grant |
| `State_Dead_StartRagdoll_Patch` | Gen2 `State_Dead.StartRagdoll` | Postfix: populate animal corpse from NPC profile | Corpse container modify |
| `BaseEntity_DropCorpse_Patch` | `BaseEntity.DropCorpse` | Postfix: capture corpse for Gen2 `State_Dead` path (stack trace check) | Sets `_lastGen2Corpse` |

**Design:** AlphaLoot runs first. Oxide plugins subscribing to `OnLootSpawn`, `OnCorpsePopulate`, etc. can overwrite loot after AlphaLoot if desired.

---

## 7) Command Surface

| Command | Purpose | Side effects | Failure modes |
|---------|---------|--------------|---------------|
| `al.additems <shortname> [shortname2]...` | Add item(s) to default containers (crate_normal, loot-barrel-1/2, box.wooden) | Modifies `StoredData`, writes JSON | Invalid shortname; no matching container |
| `al.search <shortname>` | List containers/profiles containing the item | None | Invalid shortname |
| `al.repopulateall` | Queue all LootContainers (except HackableLockedCrate) to respawn loot | `CreateInventory`, `Invoke(SpawnLoot)` | Skips HackableLockedCrate |

All commands require admin. Console or F1; no chat binding in mod.

---

## 8) Lifecycle & State Machine

- **OnLoaded:** Set `Instance`, resolve `_baseDataPath` (HarmonyConfig/AlphaLoot vs oxide/data/AlphaLoot), load config and data, set `AlphaLootContext`, optionally run `AlphaLootVanillaGenerator` when profiles empty or AutoUpdate enabled, register console commands.
- **OnUnloaded:** Unregister commands, clear `AlphaLootContext`, null `Instance` and data.
- **Save:** Explicit via `AlphaLootTools.SaveData()` (AddItems, AutoUpdate); no periodic auto-save.
- **Invariants:** `AlphaLootContext` must be valid during any populate; patches check `mod != null` before use.

---

## 9) External API Surface

No public API for other mods. Does not call other plugins. Compatible with Oxide plugins that hook `OnLootSpawn` / `OnCorpsePopulate` – they run after Harmony patches.

---

## 10) UI / CUI / Networking

Not applicable.

---

## 11) Gameplay / World Interaction

- **Containers:** `LootContainer.SpawnLoot` → clear + `PopulateLoot` → optional refresh `Invoke(SpawnLoot, delay)`.
- **Bradley/Heli:** `maxCratesToSpawn` set in `ServerInit`; crates still use `heli_crate` / `bradley_crate` profiles via `LootContainer.SpawnLoot`.
- **NPC corpses:** `HumanNPC.ApplyLoot`, `ScarecrowNPC.ApplyLoot`, Gen2 `State_Dead.StartRagdoll` → `PopulateCorpseLoot` / `profile.PopulateLoot`.
- **Unwrap:** `ItemModUnwrap.ServerCommand` → populate `player.inventory.containerMain`.
- Profile name resolution: `SupplyDrop` → `supply_drop`; `underwater_labs/` prefabs → `underwater_labs/<ShortPrefabName>`; others → `ShortPrefabName`.

---

## 12) Non-Obvious Design Decisions

- **Path priority:** `HarmonyConfig/AlphaLoot` used if directory exists; otherwise `oxide/data/AlphaLoot` with config from `oxide/config/` or fallback `HarmonyConfig/AlphaLoot.json`.
- **Supply drop:** Requires `supply_drop` in `loot_advanced` (or `loot_simple`) of main profile; if missing, supply drops fall through to vanilla unless `OverrideFancyDrop` is false (then always vanilla).
- **Gen2 corpses:** Uses `BaseEntity.DropCorpse` postfix + stack trace to detect Gen2 `State_Dead.StartRagdoll`; captures corpse, then `State_Dead_StartRagdoll_Patch` postfix populates it.
- **Era filtering:** `LootSpawn` filters by `Server.Era`; `RestrictedEras` on slots/entries skip non-matching eras.
- **Profile lookup:** Container overrides applied first; `heli_crate`/`bradley_crate` use `_heliData`/`_bradleyData` with `GetRandomLootProfile`; others use `_storedData`.

---

## 13) What NOT to Touch Without Care

- **`AlphaLootContext`:** Static; must be set before any populate and cleared on unload. Patches assume it is valid.
- **`State_Dead_StartRagdoll_Patch`:** Stack trace logic is fragile; game updates may change call stack.
- **`StoredData` dictionaries:** Use `StringComparer.OrdinalIgnoreCase`; profile names are case-insensitive.
- **`repopulateall`:** Uses `FindObjectsOfType<LootContainer>`; avoid during high entity count.
- **Loot spawn slots:** Modifying `LootSpawnSlots` in memory without saving loses changes on reload.

---

## 14) Performance Anti-Patterns to Avoid

- **Do not iterate `BaseNetworkable.serverEntities`** – Use `Find(NetworkableId)` when ID known.
- **Do not use reflection** for internal logic – Use direct method calls.
- **`repopulateall`** – Iterates all `LootContainer` instances; consider throttling or batching on large servers.

---

## Installation

1. **Unload the Oxide AlphaLoot plugin** – Do not run both simultaneously.
2. **(Optional)** Load `AlphaLootCommands.cs` for chat commands and LootCycler: `/aloot`, `al.repopulateall`, hammer a container to preview cycling loot. Requires `alphaloot.admin` permission.
3. **Console commands** (admin): `al.additems`, `al.search`, `al.repopulateall`. No Oxide needed.
4. Build and deploy:
   ```powershell
   .\build.ps1
   ```
5. Restart the server (or use `harmony.load AlphaLoot` if supported).

The mod loads `AlphaLoot.dll` from `HarmonyMods/` automatically on server start.

## Config & Data Paths

| Resource | Path |
|----------|------|
| Config | `HarmonyConfig/AlphaLoot.json` or `oxide/config/AlphaLoot.json` |
| Loot profiles | `HarmonyConfig/AlphaLoot/LootProfiles/*.json` or oxide path |
| Skin data | `HarmonyConfig/AlphaLoot/item_skin_ids.json` |
| Auto-updater state | `HarmonyConfig/AlphaLoot/AutoUpdater/do_not_edit_this_file.json` |

Directory layout mirrors `oxide/data/AlphaLoot/`. Copy existing Oxide setup to `HarmonyConfig/AlphaLoot/` for migration.

## Supported Features

| Feature | Status |
|--------|--------|
| Loot container profiles (advanced/simple) | ✅ |
| Heli crate profiles | ✅ |
| Bradley crate profiles | ✅ |
| Item unwrap (gift boxes) | ✅ |
| Bradley/Heli crate count | ✅ |
| Container overrides | ✅ |
| Global multiplier, skins | ✅ |
| NPC corpse loot (HumanNPC, ScarecrowNPC) | ✅ |
| Gen2 AI corpses (animals, State_Dead) | ✅ |
| FancyDrop override (OverrideFancyDrop config) | ✅ |
| CustomLootSpawns/EventLoot (plugins can overwrite after) | ⚠️ |
| CanPopulateLoot hook | ❌ (plugins can block via their hooks) |
| Admin commands + LootCycler | ✅ (use `AlphaLootCommands.cs` Oxide plugin) |
| Auto-updater, al.additems, al.search | ✅ (Harmony mod, admin console) |

## Vanilla profile generation

When loot profile files are missing or empty (e.g. after deleting `HarmonyConfig/AlphaLoot/LootProfiles/*.json`), the mod **automatically generates fresh vanilla loot tables** from the game's prefab definitions, matching Oxide AlphaLoot behavior. Generated files are saved to `HarmonyConfig/AlphaLoot/LootProfiles/`.

## Requirements

- Rust dedicated server with HarmonyLoader
- Existing AlphaLoot data files (or let the mod generate vanilla profiles on first load)

## Build

```powershell
.\build.ps1
```

**Output:** `D:\!RustServer\HarmonyMods\AlphaLoot.dll`
