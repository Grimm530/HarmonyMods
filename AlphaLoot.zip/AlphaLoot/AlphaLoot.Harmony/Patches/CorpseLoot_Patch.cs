using HarmonyLib;

namespace AlphaLoot.Harmony.Patches
{

    [HarmonyPatch(typeof(HumanNPC), "ApplyLoot")]
    public class HumanNPC_ApplyLoot_Patch
    {
        [HarmonyPrefix]
        static bool Prefix(HumanNPC __instance, NPCPlayerCorpse corpse)
        {
            var mod = AlphaLootMod.Instance;
            if (mod == null) return true;

            if (!mod.TryGetNPCProfile(__instance.ShortPrefabName, out var profile) || !profile.Enabled)
                return true;

            mod.PopulateCorpseLoot(__instance, corpse);
            return false; 
        }
    }

    [HarmonyPatch(typeof(ScarecrowNPC), "ApplyLoot")]
    public class ScarecrowNPC_ApplyLoot_Patch
    {
        [HarmonyPrefix]
        static bool Prefix(ScarecrowNPC __instance, NPCPlayerCorpse corpse)
        {
            var mod = AlphaLootMod.Instance;
            if (mod == null) return true;

            if (!mod.TryGetNPCProfile(__instance.ShortPrefabName, out var profile) || !profile.Enabled)
                return true;

            mod.PopulateCorpseLoot(__instance, corpse);
            return false;
        }
    }
}
