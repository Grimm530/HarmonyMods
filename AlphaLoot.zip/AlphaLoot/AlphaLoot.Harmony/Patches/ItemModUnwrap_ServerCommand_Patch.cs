using HarmonyLib;
using UnityEngine;

namespace AlphaLoot.Harmony.Patches
{
    [HarmonyPatch(typeof(ItemModUnwrap), nameof(ItemModUnwrap.ServerCommand))]
    public class ItemModUnwrap_ServerCommand_Patch
    {
        [HarmonyPrefix]
        static bool Prefix(ItemModUnwrap __instance, Item item, string command, BasePlayer player)
        {
            if (command != "unwrap" || item?.amount <= 0) return true;

            var mod = AlphaLootMod.Instance;
            if (mod == null) return true;

            if (!mod.TryGetUnwrapProfile(item.info.shortname, out var profile) || !profile.Enabled)
                return true;

            int attempts = UnityEngine.Random.Range(__instance.minTries, __instance.maxTries + 1);
            for (int i = 0; i < attempts; i++)
                profile.PopulateLoot(player.inventory.containerMain);

            item.UseItem(1);
            if (__instance.successEffect.isValid)
                Effect.server.Run(__instance.successEffect.resourcePath, player.eyes.position);

            return false;
        }
    }
}
