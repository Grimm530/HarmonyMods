using System;
using System.Reflection;
using HarmonyLib;
using UnityEngine;

namespace AlphaLoot.Harmony.Patches
{

    [HarmonyPatch]
    public static class State_Dead_StartRagdoll_Patch
    {
        [ThreadStatic]
        private static BaseCorpse _lastGen2Corpse;

        static MethodBase TargetMethod()
        {
            var deadType = AccessTools.TypeByName("Rust.Ai.Gen2.State_Dead");
            return AccessTools.FirstMethod(deadType, m => m.Name == "StartRagdoll" && m.GetParameters().Length == 0);
        }

        internal static void CaptureCorpse(BaseCorpse corpse) => _lastGen2Corpse = corpse;

        [HarmonyPostfix]
        static void Postfix(object __instance)
        {
            var corpse = _lastGen2Corpse;
            _lastGen2Corpse = null;
            if (corpse == null) return;

            var mod = AlphaLootMod.Instance;
            if (mod == null) return;

            if (!(corpse is LootableCorpse lootable) || lootable.containers == null || lootable.containers.Length == 0)
                return;

            var owner = AccessTools.Field(__instance.GetType(), "Owner")?.GetValue(__instance) as BaseEntity;
            if (owner == null) return;

            string profileName = owner.ShortPrefabName;
            if (!mod.TryGetNPCProfile(profileName, out var profile) || !profile.Enabled)
                return;

            lootable.containers[0]?.Clear();
            profile.PopulateLoot(lootable.containers[0], "");
        }
    }

    [HarmonyPatch(typeof(BaseEntity))]
    public static class BaseEntity_DropCorpse_Patch
    {
        static MethodBase TargetMethod()
        {
            var m = AccessTools.Method(typeof(BaseEntity), "DropCorpse", new[] { typeof(string), typeof(BasePlayer.PlayerFlags), typeof(ModelState) });
            if (m != null) return m;
            return AccessTools.Method(typeof(BaseEntity), "DropCorpse", new[] { typeof(string), typeof(Vector3), typeof(Quaternion), typeof(BasePlayer.PlayerFlags), typeof(ModelState) });
        }

        [HarmonyPostfix]
        static void Postfix(BaseCorpse __result)
        {
            if (__result == null) return;
            if (AlphaLootMod.Instance == null) return;

            var trace = new System.Diagnostics.StackTrace(1, false);
            for (int i = 0; i < Mathf.Min(trace.FrameCount, 8); i++)
            {
                var frame = trace.GetFrame(i);
                var method = frame?.GetMethod();
                if (method?.DeclaringType?.FullName == "Rust.Ai.Gen2.State_Dead" && method.Name == "StartRagdoll")
                {
                    State_Dead_StartRagdoll_Patch.CaptureCorpse(__result);
                    break;
                }
            }
        }
    }
}
