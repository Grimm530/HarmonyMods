using System.Collections.Generic;
using HarmonyLib;
using UnityEngine;

namespace AlphaLoot.Harmony.Patches
{
    [HarmonyPatch(typeof(LootContainer), nameof(LootContainer.SpawnLoot))]
    public class LootContainer_SpawnLoot_Patch
    {
        [HarmonyPrefix]
        static bool Prefix(LootContainer __instance)
        {
            var mod = AlphaLootMod.Instance;
            if (mod == null) return true;

            var cfg = mod.Config;
            bool isSupplyDrop = __instance is SupplyDrop;

            if (isSupplyDrop && cfg != null && !cfg.OverrideFancyDrop)
            {
                if (cfg.DebugSupplyDrops)
                    UnityEngine.Debug.Log("[AlphaLoot Debug] SupplyDrop SKIPPED - OverrideFancyDrop is false. Set to true to use AlphaLoot supply_drop table.");
                return true;
            }

            if (__instance?.inventory == null)
            {
                Debug.Log("CONTACT DEVELOPERS! LootContainer::SpawnLoot has null inventory!!!");
                return false;
            }

            string profileName = AlphaLootMod.ToProfileName(__instance);
            if (!mod.TryGetLootProfile(profileName, out var profile))
            {
                if (isSupplyDrop && cfg != null && cfg.DebugSupplyDrops)
                    UnityEngine.Debug.Log($"[AlphaLoot Debug] SupplyDrop - no profile found for '{profileName}'. Check that 'supply_drop' exists in loot_advanced in default_loottable.json");
                return true; 
            }

            if (!profile.Enabled)
                return true;

            __instance.inventory.Clear();
            ItemManager.DoRemoves();
            mod.PopulateLootContainer(__instance, profile);

            if (cfg != null && cfg.DebugSupplyDrops && __instance is SupplyDrop)
            {
                var items = new List<string>();
                for (int i = 0; i < __instance.inventory.itemList.Count; i++)
                {
                    var item = __instance.inventory.itemList[i];
                    if (item?.info != null)
                        items.Add($"{item.info.shortname} x{item.amount}");
                }
                UnityEngine.Debug.Log($"[AlphaLoot Debug] SupplyDrop populated with profile '{profileName}': {string.Join(", ", items)}");
            }

            return false;
        }
    }
}
