using HarmonyLib;

namespace AlphaLoot.Harmony.Patches
{
    [HarmonyPatch(typeof(BradleyAPC), "ServerInit")]
    public class BradleyAPC_ServerInit_Patch
    {
        [HarmonyPostfix]
        static void Postfix(BradleyAPC __instance)
        {
            var mod = AlphaLootMod.Instance;
            if (mod == null || mod.BradleyCrates < 0) return;

            if (__instance != null)
                __instance.maxCratesToSpawn = mod.BradleyCrates;
        }
    }

    [HarmonyPatch(typeof(PatrolHelicopter), "ServerInit")]
    public class PatrolHelicopter_ServerInit_Patch
    {
        [HarmonyPostfix]
        static void Postfix(PatrolHelicopter __instance)
        {
            var mod = AlphaLootMod.Instance;
            if (mod == null || mod.HelicopterCrates < 0) return;

            if (__instance != null)
                __instance.maxCratesToSpawn = mod.HelicopterCrates;
        }
    }
}
