using System;
using System.Collections.Generic;
using UnityEngine;

namespace AlphaLoot.Harmony
{

    public static class AlphaLootVanillaGenerator
    {
        private const string HELI_CRATE = "heli_crate";
        private const string BRADLEY_CRATE = "bradley_crate";
        private const string UNDERWATER_LABS = "underwater_labs/";
        private const string SUPPLY_DROP_PROFILE = "supply_drop";

        public static string ToProfileName(LootContainer container)
        {
            if (container == null) return "";
            if (container is SupplyDrop) return SUPPLY_DROP_PROFILE;
            if (container.PrefabName?.Contains(UNDERWATER_LABS) == true)
                return UNDERWATER_LABS + container.ShortPrefabName;
            return container.ShortPrefabName ?? "";
        }

        public static int PopulateContainerDefinitions(
            ref StoredData storedData,
            ref StoredData heliData,
            ref StoredData bradleyData)
        {
            storedData ??= new StoredData();
            heliData ??= new StoredData();
            bradleyData ??= new StoredData();

            heliData.loot_advanced ??= new Dictionary<string, AdvancedLootContainerProfile>(StringComparer.OrdinalIgnoreCase);
            heliData.loot_simple ??= new Dictionary<string, SimpleLootContainerProfile>(StringComparer.OrdinalIgnoreCase);
            bradleyData.loot_advanced ??= new Dictionary<string, AdvancedLootContainerProfile>(StringComparer.OrdinalIgnoreCase);
            bradleyData.loot_simple ??= new Dictionary<string, SimpleLootContainerProfile>(StringComparer.OrdinalIgnoreCase);
            storedData.loot_advanced ??= new Dictionary<string, AdvancedLootContainerProfile>(StringComparer.OrdinalIgnoreCase);
            storedData.loot_simple ??= new Dictionary<string, SimpleLootContainerProfile>(StringComparer.OrdinalIgnoreCase);
            storedData.npcs_advanced ??= new Dictionary<string, AdvancedNPCLootProfile>(StringComparer.OrdinalIgnoreCase);
            storedData.npcs_simple ??= new Dictionary<string, SimpleNPCLootProfile>(StringComparer.OrdinalIgnoreCase);
            storedData.custom_advanced ??= new Dictionary<string, AdvancedCustomLootProfile>(StringComparer.OrdinalIgnoreCase);
            storedData.custom_simple ??= new Dictionary<string, SimpleCustomLootProfile>(StringComparer.OrdinalIgnoreCase);

            int added = 0;

            var cache = FileSystem.Backend?.cache;
            if (cache != null)
            {
                foreach (var kvp in cache)
                {
                    if (kvp.Value is GameObject go)
                    {
                        var lootContainer = go.GetComponent<LootContainer>();
                        if (lootContainer != null)
                        {
                            if (CreateLootDefinitionFor(lootContainer, ref storedData, ref heliData, ref bradleyData))
                                added++;
                            continue;
                        }
                        var npcPlayer = go.GetComponent<NPCPlayer>();
                        if (npcPlayer != null)
                        {
                            if (CreateLootDefinitionFor(npcPlayer, ref storedData))
                                added++;
                        }
                    }
                }
            }

            if (ItemManager.itemList != null)
            {
                foreach (var itemDef in ItemManager.itemList)
                {
                    if (itemDef == null) continue;
                    var itemModUnwrap = itemDef.GetComponentInChildren<ItemModUnwrap>();
                    if (itemModUnwrap != null && storedData.CreateDefaultLootProfile(itemDef, itemModUnwrap))
                        added++;
                }
            }

            if (added > 0)
            {
                Debug.Log($"[AlphaLoot.Harmony] Auto-update: Added {added} new loot definition(s) to profiles. Check HarmonyConfig/AlphaLoot/LootProfiles/ and adjust if needed.");
            }

            return added;
        }

        private static bool CreateLootDefinitionFor(
            LootContainer lootContainer,
            ref StoredData storedData,
            ref StoredData heliData,
            ref StoredData bradleyData)
        {
            string profileName = ToProfileName(lootContainer);
            if (string.IsNullOrEmpty(profileName)) profileName = lootContainer.name;

            if (profileName == HELI_CRATE)
            {
                if (storedData.TryGetLootProfile(HELI_CRATE, out var prof))
                {
                    heliData.CloneLootProfile(HELI_CRATE, prof);
                    storedData.RemoveProfile(HELI_CRATE);
                    return false; 
                }
                return heliData.HasAnyProfiles ? false : heliData.CreateDefaultLootProfile(lootContainer);
            }
            if (profileName == BRADLEY_CRATE)
            {
                if (storedData.TryGetLootProfile(BRADLEY_CRATE, out var prof))
                {
                    bradleyData.CloneLootProfile(BRADLEY_CRATE, prof);
                    storedData.RemoveProfile(BRADLEY_CRATE);
                    return false;
                }
                return bradleyData.HasAnyProfiles ? false : bradleyData.CreateDefaultLootProfile(lootContainer);
            }
            return storedData.CreateDefaultLootProfile(lootContainer);
        }

        private static bool CreateLootDefinitionFor(NPCPlayer npcPlayer, ref StoredData storedData)
        {
            if (npcPlayer is HumanNPC humanNpc)
                return storedData.CreateDefaultLootProfile(npcPlayer.ShortPrefabName, humanNpc.LootSpawnSlots, npcPlayer.loadouts);
            if (npcPlayer is ScarecrowNPC scarecrowNpc)
                return storedData.CreateDefaultLootProfile(npcPlayer.ShortPrefabName, scarecrowNpc.LootSpawnSlots, npcPlayer.loadouts);
            return false;
        }
    }
}
