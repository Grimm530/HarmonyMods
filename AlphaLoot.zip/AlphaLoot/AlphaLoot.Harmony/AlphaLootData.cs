using System;
using System.Collections.Generic;
using ConVar;
using Facepunch;
using Newtonsoft.Json;
using Rust;
using UnityEngine;

namespace AlphaLoot.Harmony
{

    public static class AlphaLootContext
    {
        public static AlphaLootConfig Config { get; set; }
        public static Dictionary<string, HashSet<SkinEntry>> WeightedSkinIds { get; set; }
        public static Dictionary<string, List<ulong>> ImportedSkinIds { get; set; }
    }

    public class SkinEntry
    {
        public int Weight;
        public ulong SkinID;

        public SkinEntry() { }

        public SkinEntry(ulong skinId, int weight = 1)
        {
            SkinID = skinId;
            Weight = weight;
        }
    }

    public class BaseLootProfile
    {
        public bool Enabled = true;
        public bool AllowSkinnedItems = true;
        public float LootMultiplier = 1;
        public int MinScrapAmount;
        public int MaxScrapAmount;

        private static ItemDefinition _scrapDefinition;
        private static ItemDefinition _blueprintBase;

        [Newtonsoft.Json.JsonIgnore]
        public ItemDefinition ScrapDefinition => _scrapDefinition ? _scrapDefinition : (_scrapDefinition = ItemManager.FindItemDefinition("scrap"));

        [Newtonsoft.Json.JsonIgnore]
        public static ItemDefinition BlueprintBaseDefinition => _blueprintBase ? _blueprintBase : (_blueprintBase = ItemManager.FindItemDefinition("blueprintbase"));

        public int GetScrapAmount() => UnityEngine.Random.Range(MinScrapAmount, MaxScrapAmount);

        public virtual void PopulateLoot(ItemContainer container)
        {
            if (container.playerOwner) return;

            var cfg = AlphaLootContext.Config;
            int scrapAmount = Mathf.RoundToInt(GetScrapAmount() * (cfg?.GlobalMultiplier ?? 1f));
            if (scrapAmount > 0)
            {
                SetContainerCapacity(container, container.itemList.Count + 1);
                if (container.entityOwner is LootContainer lootContainer)
                {
                    lootContainer.scrapAmount = scrapAmount;
                    lootContainer.GenerateScrap();
                }
                else
                {
                    ItemManager.Create(ScrapDefinition, scrapAmount).MoveToContainer(container);
                }
            }
            else
            {
                SetContainerCapacity(container, container.itemList.Count);
            }
        }

        public virtual void PopulateLoot(ItemContainer itemContainer, string loadoutName) => PopulateLoot(itemContainer);

        public static void SetContainerCapacity(ItemContainer container, int i)
        {
            if (container.playerOwner) return;
            container.capacity = i;
        }
    }

    public class BaseLootContainerProfile : BaseLootProfile
    {
        public bool DestroyOnEmpty = true;
        public bool ShouldRefreshContents;
        public bool IsItemLoot = false;
        public int MinSecondsBetweenRefresh = 3600;
        public int MaxSecondsBetweenRefresh = 7200;
    }

    public class LootSpawnSlot
    {
        public LootSpawn LootDefinition;
        public int NumberToSpawn;
        public float Probability;
        public string OnlyWithLoadoutNamed;
        public Era[] Eras = Array.Empty<Era>();

        public LootSpawnSlot() { }

        public LootSpawnSlot(LootContainer.LootSpawnSlot gameSlot, bool hasCondition)
        {
            LootDefinition = new LootSpawn(gameSlot.definition, hasCondition);
            NumberToSpawn = gameSlot.numberToSpawn;
            Probability = gameSlot.probability;
            OnlyWithLoadoutNamed = gameSlot.onlyWithLoadoutNamed ?? "";
            Eras = gameSlot.eras ?? Array.Empty<Era>();
        }

        public LootSpawnSlot(global::LootSpawn gameSpawn, int numberToSpawn, bool hasCondition)
        {
            LootDefinition = new LootSpawn(gameSpawn, hasCondition);
            NumberToSpawn = numberToSpawn;
            Probability = 1f;
        }
    }

    public class LootSpawn
    {
        public ItemAmountRanged[] Items = Array.Empty<ItemAmountRanged>();
        public Entry[] SubSpawn = Array.Empty<Entry>();
        public byte[] Node = Array.Empty<byte>();

        private Entry[] _allowedSubSpawn;
        private ItemAmountRanged[] _allowedItems;
        private Era _era;

        public LootSpawn() { }

        public LootSpawn(global::LootSpawn gameSpawn, bool hasCondition)
        {
            var items = gameSpawn?.items;
            Items = new ItemAmountRanged[items?.Length ?? 0];
            if (items != null)
            {
                for (int i = 0; i < items.Length; i++)
                {
                    var g = items[i];
                    Items[i] = g != null ? new ItemAmountRanged(g.itemDef, g.amount, g.maxAmount, hasCondition) : new ItemAmountRanged();
                }
            }
            var sub = gameSpawn?.subSpawn;
            SubSpawn = new Entry[sub?.Length ?? 0];
            if (sub != null)
            {
                for (int i = 0; i < sub.Length; i++)
                {
                    var s = sub[i];
                    SubSpawn[i] = new Entry
                    {
                        Category = s.category != null ? new LootSpawn(s.category, hasCondition) : null,
                        Weight = s.weight,
                        ExtraSpawns = s.extraSpawns,
                        RestrictedEras = s.restrictedEras ?? Array.Empty<Era>()
                    };
                }
            }
        }

        private bool HasAnySpawns()
        {
            EnsureFilterUpdated();
            return (_allowedSubSpawn?.Length ?? 0) != 0 || (_allowedItems?.Length ?? 0) != 0;
        }

        private void EnsureFilterUpdated()
        {
            if (_allowedSubSpawn != null && _era == ConVar.Server.Era) return;
            _era = ConVar.Server.Era;

            if (SubSpawn == null || SubSpawn.Length == 0)
                _allowedSubSpawn = Array.Empty<Entry>();
            else
            {
                foreach (var e in SubSpawn)
                    e.Category?.EnsureFilterUpdated();
                var list = new List<Entry>();
                for (int i = 0; i < SubSpawn.Length; i++)
                {
                    var e = SubSpawn[i];
                    if (e.Category?.HasAnySpawns() != true) continue;
                    if (e.RestrictedEras != null && e.RestrictedEras.Length > 0 && Array.IndexOf(e.RestrictedEras, ConVar.Server.Era) == -1) continue;
                    list.Add(e);
                }
                _allowedSubSpawn = list.Count > 0 ? list.ToArray() : Array.Empty<Entry>();
            }

            if (Items == null || Items.Length == 0)
                _allowedItems = Array.Empty<ItemAmountRanged>();
            else
            {
                var list = new List<ItemAmountRanged>();
                for (int i = 0; i < Items.Length; i++)
                {
                    var x = Items[i];
                    if (x?.ItemDefinition != null && x.ItemDefinition.IsAllowedInEra(EraRestriction.Loot))
                        list.Add(x);
                }
                _allowedItems = list.Count > 0 ? list.ToArray() : Array.Empty<ItemAmountRanged>();
            }
        }

        public void SpawnIntoContainer(ItemContainer container, BaseLootProfile lootProfile)
        {
            EnsureFilterUpdated();
            if (_allowedSubSpawn != null && _allowedSubSpawn.Length != 0)
            {
                SubCategoryIntoContainer(container, lootProfile);
                return;
            }
            if (_allowedItems == null) return;
            int itemCount = 0;
            foreach (var item in _allowedItems)
                item?.Create(container, lootProfile.LootMultiplier, lootProfile.AllowSkinnedItems, false, ref itemCount);
        }

        private void SubCategoryIntoContainer(ItemContainer container, BaseLootProfile lootProfile)
        {
            int totalWeight = 0;
            for (int i = 0; i < _allowedSubSpawn.Length; i++)
                totalWeight += _allowedSubSpawn[i].Weight;
            int random = UnityEngine.Random.Range(0, totalWeight);
            for (int i = 0; i < _allowedSubSpawn.Length; i++)
            {
                if (_allowedSubSpawn[i].Category != null)
                {
                    totalWeight -= _allowedSubSpawn[i].Weight;
                    if (random >= totalWeight)
                    {
                        for (int j = 0; j < 1 + _allowedSubSpawn[i].ExtraSpawns; j++)
                            _allowedSubSpawn[i].Category.SpawnIntoContainer(container, lootProfile);
                        return;
                    }
                }
            }
        }

        public class Entry
        {
            public LootSpawn Category;
            public int Weight;
            public int ExtraSpawns;
            public Era[] RestrictedEras = Array.Empty<Era>();
        }
    }

    public class ItemAmount
    {
        public string Shortname;
        public float BlueprintChance;
        public float MinAmount;
        public string ItemName = "";
        public string ItemText = "";
        public ulong SkinID;
        public bool DontMultiply;
        public ConditionItem Condition = new ConditionItem();

        private int _itemId = -1;
        private ItemDefinition _itemDefinition;

        [Newtonsoft.Json.JsonIgnore]
        public int ItemID => _itemId < 0 ? (_itemId = ItemDefinition ? ItemDefinition.itemid : -1) : _itemId;

        [Newtonsoft.Json.JsonIgnore]
        public ItemDefinition ItemDefinition => !_itemDefinition && !string.IsNullOrEmpty(Shortname) ? (_itemDefinition = ItemManager.FindItemDefinition(Shortname)) : _itemDefinition;

        public ItemAmount() { }

        public virtual float GetAmount(float lootMultiplier)
        {
            var def = ItemDefinition;
            if (!def) return 0;
            var cfg = AlphaLootContext.Config;
            bool isStackable = (def.stackable > 1 && !def.condition.enabled) || (cfg?.MultiplyUnstackable ?? false);
            if (!isStackable || DontMultiply) return Mathf.Clamp(MinAmount, 1f, float.MaxValue);
            return Mathf.Clamp((MinAmount * lootMultiplier) * (cfg?.GlobalMultiplier ?? 1f), 1f, float.MaxValue);
        }

        public ulong GetSkinID(bool allowRandomSkins)
        {
            if (SkinID != 0) return SkinID;
            if (allowRandomSkins) return RandomSkinID();
            return 0;
        }

        private ulong RandomSkinID()
        {
            if (AlphaLootContext.WeightedSkinIds != null &&
                AlphaLootContext.WeightedSkinIds.TryGetValue(Shortname, out var set) && set.Count > 0)
            {
                int totalWeight = 0;
                foreach (var x in set)
                    totalWeight += x.Weight;
                int random = UnityEngine.Random.Range(0, totalWeight);
                foreach (var e in set)
                {
                    totalWeight -= e.Weight;
                    if (random >= totalWeight) return e.SkinID;
                }
            }
            if (AlphaLootContext.Config?.IgnoreSkinsFor?.Contains(Shortname) != true &&
                AlphaLootContext.ImportedSkinIds?.TryGetValue(Shortname, out var list) == true && list.Count > 0)
                return list[UnityEngine.Random.Range(0, list.Count)];
            return 0;
        }

        public float GetConditionFraction() => Condition == null ? 1f : UnityEngine.Random.Range(Condition.MinCondition, Condition.MaxCondition);
        public bool WantsBlueprint() => UnityEngine.Random.Range(0f, 1f) < BlueprintChance;

        public class ConditionItem
        {
            public float MinCondition = 1f;
            public float MaxCondition = 1f;
        }
    }

    public class ItemAmountRanged : ItemAmount
    {
        public float MaxAmount = -1f;

        public ItemAmountRanged() : base() { }

        public ItemAmountRanged(ItemDefinition itemDef, float amount, float maxAmount, bool hasCondition)
        {
            Shortname = itemDef?.shortname ?? "";
            BlueprintChance = itemDef != null && itemDef.spawnAsBlueprint ? 1f : 0f;
            MinAmount = amount;
            MaxAmount = Mathf.Max(maxAmount, amount);
            if (hasCondition && itemDef != null && itemDef.condition.enabled)
            {
                Condition = new ConditionItem
                {
                    MinCondition = itemDef.condition.foundCondition.fractionMin,
                    MaxCondition = itemDef.condition.foundCondition.fractionMax
                };
            }
        }

        public void Create(ItemContainer container, float lootMultiplier, bool allowSkinnedItems, bool expandContainer, ref int itemCount)
        {
            if (DontMultiply && container != null)
            {
                for (int i = 0; i < container.itemList.Count; i++)
                {
                    if (container.itemList[i]?.info != null && string.Equals(container.itemList[i].info.shortname, Shortname, StringComparison.OrdinalIgnoreCase))
                        return;
                }
            }

            Item item = null;
            if (WantsBlueprint())
            {
                var bpDef = BaseLootProfile.BlueprintBaseDefinition;
                if (!bpDef) return;
                item = ItemManager.Create(bpDef, 1, 0UL);
                item.blueprintTarget = ItemID;
            }
            else
            {
                item = ItemManager.CreateByItemID(ItemID, (int)GetAmount(lootMultiplier), GetSkinID(allowSkinnedItems));
                if (!string.IsNullOrEmpty(ItemName)) item.name = ItemName;
                if (!string.IsNullOrEmpty(ItemText)) item.text = ItemText;
                if (item.hasCondition) item.condition = GetConditionFraction() * item.info.condition.max;
            }
            item.OnVirginSpawn();
            if (!item.MoveToContainer(container, -1, true))
            {
                if (!container.playerOwner) item.Remove(0f);
                else item.Drop(container.playerOwner.GetDropPosition(), container.playerOwner.GetDropVelocity(), Quaternion.identity);
            }
            itemCount++;
            CreateAdditionalItems(container, lootMultiplier, allowSkinnedItems, expandContainer, ref itemCount);
        }

        public virtual void CreateAdditionalItems(ItemContainer container, float lootMultiplier, bool allowSkinnedItems, bool expandContainer, ref int itemCount) { }

        public override float GetAmount(float lootMultiplier)
        {
            var def = ItemDefinition;
            if (!def) return 0;
            var cfg = AlphaLootContext.Config;
            bool isStackable = (def.stackable > 1 && !def.condition.enabled) || (cfg?.MultiplyUnstackable ?? false);
            if (MinAmount == MaxAmount)
            {
                if (!isStackable || DontMultiply) return Mathf.Clamp(MinAmount, 1f, float.MaxValue);
                return Mathf.Clamp((MinAmount * lootMultiplier) * (cfg?.GlobalMultiplier ?? 1f), 1f, float.MaxValue);
            }
            if (!isStackable || DontMultiply) return Mathf.Clamp(UnityEngine.Random.Range(MinAmount, MaxAmount), 1f, float.MaxValue);
            return Mathf.Clamp((UnityEngine.Random.Range(MinAmount, MaxAmount) * lootMultiplier) * (cfg?.GlobalMultiplier ?? 1f), 1f, float.MaxValue);
        }
    }

    public class ItemAmountWeighted : ItemAmountRanged
    {
        public int Weight = 1;
        public Era[] RestrictedEras = Array.Empty<Era>();
    }

    public class ItemAmountSpawnsWith : ItemAmountWeighted
    {
        public ItemAmountWeighted[] SpawnsWith = Array.Empty<ItemAmountWeighted>();

        public override void CreateAdditionalItems(ItemContainer container, float lootMultiplier, bool allowSkinnedItems, bool expandContainer, ref int itemCount)
        {
            if (SpawnsWith == null || SpawnsWith.Length == 0) return;
            foreach (var sw in SpawnsWith)
            {
                if (!container.playerOwner && expandContainer) container.capacity++;
                sw.Create(container, lootMultiplier, allowSkinnedItems, expandContainer, ref itemCount);
            }
        }
    }

    public class SimpleLootContainerProfile : BaseLootContainerProfile
    {
        public int MinimumItems;
        public int MaximumItems;
        public ItemAmountSpawnsWith[] Items;

        public override void PopulateLoot(ItemContainer container)
        {
            int count = UnityEngine.Random.Range(MinimumItems, MaximumItems + 1);
            SetContainerCapacity(container, count);
            var items = Facepunch.Pool.Get<List<ItemAmountSpawnsWith>>();
            items.AddRange(Items);

            int itemCount = 0;
            while (itemCount < count)
            {
                int totalWeight = 0;
                for (int i = 0; i < items.Count; i++) totalWeight += items[i].Weight;
                int random = UnityEngine.Random.Range(0, totalWeight);
                for (int y = 0; y < items.Count; y++)
                {
                    var iw = items[y];
                    totalWeight -= iw.Weight;
                    if (random >= totalWeight)
                    {
                        items.Remove(iw);
                        iw.Create(container, LootMultiplier, AllowSkinnedItems, true, ref itemCount);
                        break;
                    }
                }
                if (items.Count == 0) items.AddRange(Items);
            }
            SetContainerCapacity(container, items.Count);
            Facepunch.Pool.FreeUnmanaged(ref items);
            base.PopulateLoot(container);
        }
    }

    public class AdvancedLootContainerProfile : BaseLootContainerProfile
    {
        public LootSpawnSlot[] LootSpawnSlots;
        public int MaximumItems = -1;

        public AdvancedLootContainerProfile() { }

        public AdvancedLootContainerProfile(LootContainer container)
        {
            bool hasCondition = container.SpawnType == LootContainer.spawnType.ROADSIDE || container.SpawnType == LootContainer.spawnType.TOWN;
            DestroyOnEmpty = container.destroyOnEmpty;
            ShouldRefreshContents = !float.IsInfinity(container.minSecondsBetweenRefresh) && !float.IsInfinity(container.maxSecondsBetweenRefresh) && container.shouldRefreshContents;
            int scrapAmount = container.scrapAmount;
            if (scrapAmount <= 0) scrapAmount = 1;
            MinScrapAmount = MaxScrapAmount = scrapAmount;
            MinSecondsBetweenRefresh = !ShouldRefreshContents ? 0 : Mathf.RoundToInt(container.minSecondsBetweenRefresh);
            MaxSecondsBetweenRefresh = !ShouldRefreshContents ? 0 : Mathf.RoundToInt(container.maxSecondsBetweenRefresh);
            MaximumItems = container.inventorySlots;
            var slots = container.LootSpawnSlots;
            if (slots != null && slots.Length > 0)
            {
                LootSpawnSlots = new LootSpawnSlot[slots.Length];
                for (int i = 0; i < slots.Length; i++)
                    LootSpawnSlots[i] = new LootSpawnSlot(slots[i], hasCondition);
            }
            else if (container.lootDefinition)
            {
                LootSpawnSlots = new[] { new LootSpawnSlot(container.lootDefinition, container.maxDefinitionsToSpawn, hasCondition) };
            }
        }

        public AdvancedLootContainerProfile(ItemModUnwrap itemModUnwrap)
        {
            MaximumItems = -1;
            IsItemLoot = true;
            LootSpawnSlots = new[] { new LootSpawnSlot(itemModUnwrap.revealList, 1, false) };
        }

        public AdvancedLootContainerProfile(AdvancedLootContainerProfile copy)
        {
            if (copy == null) return;
            DestroyOnEmpty = copy.DestroyOnEmpty;
            AllowSkinnedItems = copy.AllowSkinnedItems;
            ShouldRefreshContents = copy.ShouldRefreshContents;
            MinSecondsBetweenRefresh = copy.MinSecondsBetweenRefresh;
            MaxSecondsBetweenRefresh = copy.MaxSecondsBetweenRefresh;
            MinScrapAmount = copy.MinScrapAmount;
            MaxScrapAmount = copy.MaxScrapAmount;
            MaximumItems = copy.MaximumItems;
            LootSpawnSlots = copy.LootSpawnSlots;
            Enabled = copy.Enabled;
        }

        public override void PopulateLoot(ItemContainer container)
        {
            if (LootSpawnSlots != null && LootSpawnSlots.Length != 0)
            {
                SetContainerCapacity(container, MaximumItems == -1 ? 36 : MaximumItems);
                foreach (var slot in LootSpawnSlots)
                {
                    if (slot?.LootDefinition == null) continue;
                    if (slot.Eras != null && slot.Eras.Length != 0 && Array.IndexOf(slot.Eras, ConVar.Server.Era) == -1) continue;
                    for (int j = 0; j < slot.NumberToSpawn; j++)
                    {
                        if (UnityEngine.Random.Range(0f, 1f) <= slot.Probability)
                            slot.LootDefinition.SpawnIntoContainer(container, this);
                    }
                }
            }
            base.PopulateLoot(container);
        }
    }

    public class SimpleNPCLootProfile : BaseLootProfile
    {
        public int MinimumItems;
        public int MaximumItems;
        public ItemAmountSpawnsWith[] Items;

        public override void PopulateLoot(ItemContainer container)
        {
            int count = UnityEngine.Random.Range(MinimumItems, MaximumItems + 1);
            SetContainerCapacity(container, count);
            var items = Facepunch.Pool.Get<List<ItemAmountSpawnsWith>>();
            items.AddRange(Items);

            int itemCount = 0;
            while (itemCount < count)
            {
                int totalWeight = 0;
                for (int i = 0; i < items.Count; i++) totalWeight += items[i].Weight;
                int random = UnityEngine.Random.Range(0, totalWeight);
                for (int y = 0; y < items.Count; y++)
                {
                    var iw = items[y];
                    totalWeight -= iw.Weight;
                    if (random >= totalWeight)
                    {
                        items.Remove(iw);
                        iw.Create(container, LootMultiplier, AllowSkinnedItems, true, ref itemCount);
                        break;
                    }
                }
                if (items.Count == 0) items.AddRange(Items);
            }
            SetContainerCapacity(container, items.Count);
            Facepunch.Pool.FreeUnmanaged(ref items);
            base.PopulateLoot(container);
        }
    }

    public class AdvancedNPCLootProfile : BaseLootProfile
    {
        public LootSpawnSlot[] LootSpawnSlots;
        public int MaximumItems = -1;

        public AdvancedNPCLootProfile() { }

        public AdvancedNPCLootProfile(LootContainer.LootSpawnSlot[] lootSpawnSlots)
        {
            LootSpawnSlots = new LootSpawnSlot[lootSpawnSlots?.Length ?? 0];
            for (int i = 0; i < (lootSpawnSlots?.Length ?? 0); i++)
                LootSpawnSlots[i] = new LootSpawnSlot(lootSpawnSlots[i], true);
        }

        public override void PopulateLoot(ItemContainer container, string loadoutName)
        {
            if (LootSpawnSlots != null && LootSpawnSlots.Length != 0)
            {
                SetContainerCapacity(container, MaximumItems == -1 ? 36 : MaximumItems);
                foreach (var slot in LootSpawnSlots)
                {
                    if (slot?.LootDefinition == null) continue;
                    if (!string.IsNullOrEmpty(slot.OnlyWithLoadoutNamed) && slot.OnlyWithLoadoutNamed != loadoutName) continue;
                    for (int j = 0; j < slot.NumberToSpawn; j++)
                    {
                        if (UnityEngine.Random.Range(0f, 1f) <= slot.Probability)
                            slot.LootDefinition.SpawnIntoContainer(container, this);
                    }
                }
            }
            base.PopulateLoot(container);
        }
    }

    public class SimpleCustomLootProfile : BaseLootProfile
    {
        public int MinimumItems;
        public int MaximumItems;
        public ItemAmountSpawnsWith[] Items;

        public override void PopulateLoot(ItemContainer container)
        {
            int count = UnityEngine.Random.Range(MinimumItems, MaximumItems + 1);
            SetContainerCapacity(container, count);
            var items = Facepunch.Pool.Get<List<ItemAmountSpawnsWith>>();
            items.AddRange(Items);

            int itemCount = 0;
            while (itemCount < count)
            {
                int totalWeight = 0;
                for (int i = 0; i < items.Count; i++) totalWeight += items[i].Weight;
                int random = UnityEngine.Random.Range(0, totalWeight);
                for (int y = 0; y < items.Count; y++)
                {
                    var iw = items[y];
                    totalWeight -= iw.Weight;
                    if (random >= totalWeight)
                    {
                        items.Remove(iw);
                        iw.Create(container, LootMultiplier, AllowSkinnedItems, true, ref itemCount);
                        break;
                    }
                }
                if (items.Count == 0) items.AddRange(Items);
            }
            SetContainerCapacity(container, items.Count);
            Facepunch.Pool.FreeUnmanaged(ref items);
            base.PopulateLoot(container);
        }
    }

    public class AdvancedCustomLootProfile : BaseLootProfile
    {
        public LootSpawnSlot[] LootSpawnSlots;
        public int MaximumItems = 24;

        public override void PopulateLoot(ItemContainer container)
        {
            if (LootSpawnSlots != null && LootSpawnSlots.Length != 0)
            {
                SetContainerCapacity(container, Mathf.Min(MaximumItems, 24));
                foreach (var slot in LootSpawnSlots)
                {
                    if (slot?.LootDefinition == null) continue;
                    for (int j = 0; j < slot.NumberToSpawn; j++)
                    {
                        if (UnityEngine.Random.Range(0f, 1f) <= slot.Probability)
                            slot.LootDefinition.SpawnIntoContainer(container, this);
                    }
                }
            }
            base.PopulateLoot(container);
        }
    }

    public class StoredData
    {
        public Dictionary<string, SimpleLootContainerProfile> loot_simple = new Dictionary<string, SimpleLootContainerProfile>(StringComparer.OrdinalIgnoreCase);
        public Dictionary<string, AdvancedLootContainerProfile> loot_advanced = new Dictionary<string, AdvancedLootContainerProfile>(StringComparer.OrdinalIgnoreCase);
        public Dictionary<string, AdvancedNPCLootProfile> npcs_advanced = new Dictionary<string, AdvancedNPCLootProfile>(StringComparer.OrdinalIgnoreCase);
        public Dictionary<string, SimpleNPCLootProfile> npcs_simple = new Dictionary<string, SimpleNPCLootProfile>(StringComparer.OrdinalIgnoreCase);
        public Dictionary<string, AdvancedCustomLootProfile> custom_advanced = new Dictionary<string, AdvancedCustomLootProfile>(StringComparer.OrdinalIgnoreCase);
        public Dictionary<string, SimpleCustomLootProfile> custom_simple = new Dictionary<string, SimpleCustomLootProfile>(StringComparer.OrdinalIgnoreCase);
        public Dictionary<string, List<string>> npc_loadouts = new Dictionary<string, List<string>>(StringComparer.OrdinalIgnoreCase);

        private List<BaseLootContainerProfile> _randomList = new List<BaseLootContainerProfile>();

        public bool HasAnyProfiles =>
            (loot_advanced?.Count ?? 0) > 0 || (loot_simple?.Count ?? 0) > 0 ||
            (npcs_advanced?.Count ?? 0) > 0 || (npcs_simple?.Count ?? 0) > 0 ||
            (custom_advanced?.Count ?? 0) > 0 || (custom_simple?.Count ?? 0) > 0;

        public bool CreateDefaultLootProfile(LootContainer container)
        {
            string name = AlphaLootVanillaGenerator.ToProfileName(container);
            if (string.IsNullOrEmpty(name)) name = container.name;
            if ((loot_advanced?.ContainsKey(name) ?? false) || (loot_simple?.ContainsKey(name) ?? false)) return false;
            loot_advanced ??= new Dictionary<string, AdvancedLootContainerProfile>(StringComparer.OrdinalIgnoreCase);
            loot_advanced.Add(name, new AdvancedLootContainerProfile(container));
            return true;
        }

        public bool CreateDefaultLootProfile(ItemDefinition itemDef, ItemModUnwrap itemModUnwrap)
        {
            if (itemDef == null || (loot_advanced?.ContainsKey(itemDef.shortname) ?? false) || (loot_simple?.ContainsKey(itemDef.shortname) ?? false)) return false;
            loot_advanced ??= new Dictionary<string, AdvancedLootContainerProfile>(StringComparer.OrdinalIgnoreCase);
            loot_advanced.Add(itemDef.shortname, new AdvancedLootContainerProfile(itemModUnwrap));
            return true;
        }

        public bool CreateDefaultLootProfile(string shortPrefabName, LootContainer.LootSpawnSlot[] slots, PlayerInventoryProperties[] loadouts)
        {
            npc_loadouts ??= new Dictionary<string, List<string>>(StringComparer.OrdinalIgnoreCase);
            if (!npc_loadouts.TryGetValue(shortPrefabName, out var list))
                npc_loadouts[shortPrefabName] = list = new List<string>();
            if (loadouts != null)
                foreach (var p in loadouts)
                    if (p != null && !list.Contains(p.niceName))
                        list.Add(p.niceName);
            if ((npcs_advanced?.ContainsKey(shortPrefabName) ?? false) || (npcs_simple?.ContainsKey(shortPrefabName) ?? false)) return false;
            npcs_advanced ??= new Dictionary<string, AdvancedNPCLootProfile>(StringComparer.OrdinalIgnoreCase);
            npcs_advanced.Add(shortPrefabName, new AdvancedNPCLootProfile(slots));
            return true;
        }

        public void CloneLootProfile(string shortname, BaseLootProfile source)
        {
            if (source is AdvancedLootContainerProfile adv)
            {
                loot_advanced ??= new Dictionary<string, AdvancedLootContainerProfile>(StringComparer.OrdinalIgnoreCase);
                loot_advanced[shortname] = new AdvancedLootContainerProfile(adv);
            }
        }

        public void RemoveProfile(string shortname)
        {
            loot_simple?.Remove(shortname);
            loot_advanced?.Remove(shortname);
            npcs_simple?.Remove(shortname);
            npcs_advanced?.Remove(shortname);
        }

        public bool TryGetLootProfile(string shortname, out BaseLootContainerProfile profile)
        {
            if (loot_advanced.TryGetValue(shortname, out var adv))
            {
                profile = adv;
                return true;
            }
            if (loot_simple.TryGetValue(shortname, out var sim))
            {
                profile = sim;
                return true;
            }
            profile = null;
            return false;
        }

        public bool TryGetNPCProfile(string shortname, out BaseLootProfile profile)
        {
            if (npcs_advanced.TryGetValue(shortname, out var adv))
            {
                profile = adv;
                return true;
            }
            if (npcs_simple.TryGetValue(shortname, out var sim))
            {
                profile = sim;
                return true;
            }
            profile = null;
            return false;
        }

        public bool TryGetCustomProfile(string shortname, out BaseLootProfile profile)
        {
            if (custom_advanced.TryGetValue(shortname, out var adv))
            {
                profile = adv;
                return true;
            }
            if (custom_simple.TryGetValue(shortname, out var sim))
            {
                profile = sim;
                return true;
            }
            profile = null;
            return false;
        }

        public bool GetRandomLootProfile(out BaseLootContainerProfile profile)
        {
            if (_randomList.Count == 0)
            {
                _randomList.AddRange(loot_simple.Values);
                _randomList.AddRange(loot_advanced.Values);
            }
        restart:
            if (_randomList.Count == 0)
            {
                profile = null;
                return false;
            }
            profile = _randomList[UnityEngine.Random.Range(0, _randomList.Count)];
            _randomList.Remove(profile);
            if (!profile.Enabled) goto restart;
            return true;
        }
    }
}
