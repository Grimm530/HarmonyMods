using System;
using System.Collections.Generic;
using System.IO;
using Newtonsoft.Json;
using UnityEngine;

namespace AlphaLoot.Harmony
{
    public class AlphaLootMod : IHarmonyModHooks
    {
        public static AlphaLootMod Instance { get; private set; }

        private const string HELI_CRATE = "heli_crate";
        private const string BRADLEY_CRATE = "bradley_crate";
        private const string UNDERWATER_LABS = "underwater_labs/";

        private AlphaLootConfig _config;
        private StoredData _storedData;
        private StoredData _heliData;
        private StoredData _bradleyData;

        private string _dataPath;
        private string _configPath;

        public AlphaLootConfig Config => _config;
        public StoredData StoredData => _storedData;
        public StoredData HeliData => _heliData;
        public StoredData BradleyData => _bradleyData;

        private string _baseDataPath; 
        public string BaseDataPath => _baseDataPath;

        public void OnLoaded(OnHarmonyModLoadedArgs args)
        {
            Instance = this;

            string serverRoot = Path.GetDirectoryName(Application.dataPath) ?? ".";
            string harmonyBase = Path.Combine(serverRoot, "HarmonyConfig", "AlphaLoot");
            string oxideBase = Path.Combine(serverRoot, "oxide", "data", "AlphaLoot");

            if (Directory.Exists(harmonyBase))
            {
                _baseDataPath = harmonyBase;
                _configPath = Path.Combine(serverRoot, "HarmonyConfig", "AlphaLoot.json");
            }
            else
            {
                _baseDataPath = oxideBase;
                _configPath = Path.Combine(serverRoot, "oxide", "config", "AlphaLoot.json");
                if (!File.Exists(_configPath))
                    _configPath = Path.Combine(serverRoot, "HarmonyConfig", "AlphaLoot.json");
            }

            _dataPath = Path.Combine(_baseDataPath, "LootProfiles");

            LoadConfig();
            LoadData();
            SetContext();

            if (_config?.AutoUpdate == true)
                AlphaLootTools.RunAutoUpdater(this);

            RegisterCommands();

            var lootCount = (_storedData?.loot_advanced?.Count ?? 0) + (_storedData?.loot_simple?.Count ?? 0);
            var hasSupplyDrop = _storedData?.loot_advanced?.ContainsKey(SUPPLY_DROP_PROFILE) == true || _storedData?.loot_simple?.ContainsKey(SUPPLY_DROP_PROFILE) == true;
            Debug.Log($"[AlphaLoot.Harmony] Loaded from {_baseDataPath}. Loot: {lootCount}, Heli: {(_heliData?.loot_advanced?.Count ?? 0) + (_heliData?.loot_simple?.Count ?? 0)}, Bradley: {(_bradleyData?.loot_advanced?.Count ?? 0) + (_bradleyData?.loot_simple?.Count ?? 0)}. SupplyDrop: {(hasSupplyDrop ? "yes" : "NO - add supply_drop to loot_advanced")}, OverrideFancyDrop: {_config?.OverrideFancyDrop}");
        }

        public void OnUnloaded(OnHarmonyModUnloadedArgs args)
        {
            UnregisterCommands();
            AlphaLootContext.Config = null;
            AlphaLootContext.WeightedSkinIds = null;
            AlphaLootContext.ImportedSkinIds = null;
            Instance = null;
            _storedData = null;
            _heliData = null;
            _bradleyData = null;
            Debug.Log("[AlphaLoot.Harmony] Unloaded.");
        }

        private void RegisterCommands()
        {
            try
            {
                var addCmd = new ConsoleSystem.Command
                {
                    Name = "additems",
                    Parent = "al",
                    FullName = "al.additems",
                    ServerAdmin = true,
                    Variable = false,
                    Call = a => { if (CanUseCommand(a)) AlphaLootTools.AddItems(a, a.Args, Instance); }
                };
                var searchCmd = new ConsoleSystem.Command
                {
                    Name = "search",
                    Parent = "al",
                    FullName = "al.search",
                    ServerAdmin = true,
                    Variable = false,
                    Call = a => { if (CanUseCommand(a)) AlphaLootTools.SearchItem(a, a?.Args?.Length > 0 ? a.GetString(0) : "", Instance); }
                };
                var repopulateCmd = new ConsoleSystem.Command
                {
                    Name = "repopulateall",
                    Parent = "al",
                    FullName = "al.repopulateall",
                    ServerAdmin = true,
                    Variable = false,
                    Call = a => { if (CanUseCommand(a)) RepopulateAllLoot(a); }
                };
                ConsoleSystem.Index.Server.Dict["al.additems"] = addCmd;
                ConsoleSystem.Index.Server.Dict["al.search"] = searchCmd;
                ConsoleSystem.Index.Server.Dict["al.repopulateall"] = repopulateCmd;
                var all = new List<ConsoleSystem.Command>(ConsoleSystem.Index.All);
                all.Add(addCmd);
                all.Add(searchCmd);
                all.Add(repopulateCmd);
                ConsoleSystem.Index.All = all.ToArray();
            }
            catch (Exception ex) { Debug.LogError($"[AlphaLoot.Harmony] Command registration: {ex.Message}"); }
        }

        private void UnregisterCommands()
        {
            try
            {
                ConsoleSystem.Index.Server.Dict.Remove("al.additems");
                ConsoleSystem.Index.Server.Dict.Remove("al.search");
                ConsoleSystem.Index.Server.Dict.Remove("al.repopulateall");
            }
            catch { }
        }

        private void RepopulateAllLoot(ConsoleSystem.Arg arg)
        {
            var containers = UnityEngine.Object.FindObjectsOfType<LootContainer>();
            int queued = 0;
            for (int i = 0; i < (containers?.Length ?? 0); i++)
            {
                var lc = containers[i];
                if (lc == null || lc.IsDestroyed) continue;
                if (lc is HackableLockedCrate) continue;
                if (lc.inventory == null)
                {
                    lc.CreateInventory(true);
                    lc.OnInventoryFirstCreated(lc.inventory);
                }
                lc.CancelInvoke(lc.SpawnLoot);
                lc.Invoke(lc.SpawnLoot, UnityEngine.Random.Range(1f, 20f));
                queued++;
            }
            string msg = $"Queued {queued} containers to respawn loot (skipped HackableLockedCrate).";
            if (arg?.Connection != null)
                arg.ReplyWith(msg);
            else
                Debug.Log($"[AlphaLoot.Harmony] {msg}");
        }

        private static bool CanUseCommand(ConsoleSystem.Arg arg)
        {
            if (arg.Connection == null) return true;
            var p = arg.Player();
            return p != null && p.IsAdmin;
        }

        private void LoadConfig()
        {
            try
            {
                if (File.Exists(_configPath))
                {
                    var json = File.ReadAllText(_configPath);
                    _config = JsonConvert.DeserializeObject<AlphaLootConfig>(json);
                }
                if (_config == null)
                {
                    _config = new AlphaLootConfig();
                    if (_configPath != null)
                    {
                        var dir = Path.GetDirectoryName(_configPath);
                        if (!string.IsNullOrEmpty(dir) && !Directory.Exists(dir))
                            Directory.CreateDirectory(dir);
                        File.WriteAllText(_configPath, JsonConvert.SerializeObject(_config, Formatting.Indented));
                    }
                }
            }
            catch (Exception ex)
            {
                Debug.LogError($"[AlphaLoot.Harmony] Config load error: {ex.Message}");
                _config = new AlphaLootConfig();
            }
        }

        private void LoadData()
        {
            _storedData = LoadStoredData(_config?.ProfileName ?? "default_loottable");
            _heliData = LoadStoredData(_config?.HeliProfileName ?? "default_heli_loottable");
            _bradleyData = LoadStoredData(_config?.BradleyProfileName ?? "default_bradley_loottable");

            if (_heliData != null)
            {
                _heliData.loot_advanced ??= new Dictionary<string, AdvancedLootContainerProfile>(StringComparer.OrdinalIgnoreCase);
                _heliData.loot_simple ??= new Dictionary<string, SimpleLootContainerProfile>(StringComparer.OrdinalIgnoreCase);
            }
            if (_bradleyData != null)
            {
                _bradleyData.loot_advanced ??= new Dictionary<string, AdvancedLootContainerProfile>(StringComparer.OrdinalIgnoreCase);
                _bradleyData.loot_simple ??= new Dictionary<string, SimpleLootContainerProfile>(StringComparer.OrdinalIgnoreCase);
            }

            bool needsVanilla = (_storedData != null && !_storedData.HasAnyProfiles)
                || (_heliData != null && !_heliData.HasAnyProfiles)
                || (_bradleyData != null && !_bradleyData.HasAnyProfiles);

            bool shouldMergeNew = _config?.AutoUpdate == true;

            if (needsVanilla || shouldMergeNew)
            {
                AlphaLootVanillaGenerator.PopulateContainerDefinitions(ref _storedData, ref _heliData, ref _bradleyData);
                AlphaLootTools.SaveData(this);
            }
        }

        private StoredData LoadStoredData(string profileName)
        {
            string path = Path.Combine(_dataPath, profileName + ".json");
            try
            {
                if (File.Exists(path))
                {
                    var json = File.ReadAllText(path);
                    return JsonConvert.DeserializeObject<StoredData>(json);
                }
            }
            catch (Exception ex)
            {
                Debug.LogError($"[AlphaLoot.Harmony] Failed to load {path}: {ex.Message}");
            }
            return new StoredData();
        }

        private void SetContext()
        {
            AlphaLootContext.Config = _config;
            AlphaLootContext.WeightedSkinIds = LoadSkinData();
            AlphaLootContext.ImportedSkinIds = new Dictionary<string, List<ulong>>(StringComparer.OrdinalIgnoreCase);
        }

        private Dictionary<string, HashSet<SkinEntry>> LoadSkinData()
        {
            string skinPath = Path.Combine(_baseDataPath ?? Path.Combine(Path.GetDirectoryName(Application.dataPath) ?? ".", "oxide", "data", "AlphaLoot"), "item_skin_ids.json");
            try
            {
                if (File.Exists(skinPath))
                {
                    var json = File.ReadAllText(skinPath);
                    return JsonConvert.DeserializeObject<Dictionary<string, HashSet<SkinEntry>>>(json)
                        ?? new Dictionary<string, HashSet<SkinEntry>>(StringComparer.OrdinalIgnoreCase);
                }
            }
            catch { }
            return new Dictionary<string, HashSet<SkinEntry>>(StringComparer.OrdinalIgnoreCase);
        }

        private const string SUPPLY_DROP_PROFILE = "supply_drop";

        public static string ToProfileName(LootContainer container)
        {
            if (container == null) return "";
            if (container is SupplyDrop)
                return SUPPLY_DROP_PROFILE;
            if (container.PrefabName?.Contains(UNDERWATER_LABS) == true)
                return UNDERWATER_LABS + container.ShortPrefabName;
            return container.ShortPrefabName ?? "";
        }

        public bool TryGetContainerOverride(string profileName, out string overrideProfile)
        {
            overrideProfile = null;
            return _config != null && _config.TryGetContainerOverride(profileName, out overrideProfile);
        }

        public bool TryGetLootProfile(string profileName, out BaseLootContainerProfile profile)
        {
            profile = null;
            if (TryGetContainerOverride(profileName, out var over))
                profileName = over;

            if (profileName == HELI_CRATE && _heliData != null && _heliData.GetRandomLootProfile(out profile))
                return true;
            if (profileName == BRADLEY_CRATE && _bradleyData != null && _bradleyData.GetRandomLootProfile(out profile))
                return true;
            return _storedData != null && _storedData.TryGetLootProfile(profileName, out profile);
        }

        public bool TryGetUnwrapProfile(string itemShortname, out BaseLootContainerProfile profile)
        {
            profile = null;
            return _storedData != null && _storedData.TryGetLootProfile(itemShortname, out profile);
        }

        public bool TryGetNPCProfile(string profileName, out BaseLootProfile profile)
        {
            profile = null;
            if (TryGetContainerOverride(profileName, out var over))
                profileName = over;
            return _storedData != null && _storedData.TryGetNPCProfile(profileName, out profile);
        }

        public void PopulateCorpseLoot(BaseEntity entity, LootableCorpse corpse)
        {
            if (entity == null || corpse?.containers == null || corpse.containers.Length == 0) return;

            string profileName = entity.ShortPrefabName;
            if (TryGetContainerOverride(profileName, out var over))
                profileName = over;

            if (!TryGetNPCProfile(profileName, out var profile) || !profile.Enabled) return;

            string loadoutName = entity is HumanNPC humanNpc ? humanNpc.GetLoadoutName() : "";
            profile.PopulateLoot(corpse.containers[0], loadoutName);
        }

        public void PopulateLootContainer(LootContainer container, BaseLootContainerProfile lootProfile)
        {
            if (container == null || lootProfile == null) return;

            container.destroyOnEmpty = lootProfile.DestroyOnEmpty;
            lootProfile.PopulateLoot(container.inventory);
            container.CancelInvoke(container.SpawnLoot);

            if (lootProfile.ShouldRefreshContents)
            {
                float delay = Mathf.Max(60, UnityEngine.Random.Range(lootProfile.MinSecondsBetweenRefresh, lootProfile.MaxSecondsBetweenRefresh));
                container.Invoke(container.SpawnLoot, delay);
            }
        }

        public int BradleyCrates => _config?.BradleyCrates ?? -1;
        public int HelicopterCrates => _config?.HelicopterCrates ?? -1;
    }
}
