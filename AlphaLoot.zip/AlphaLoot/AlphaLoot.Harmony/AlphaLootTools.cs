using System;
using System.Collections.Generic;
using System.IO;
using Facepunch;
using Newtonsoft.Json;
using UnityEngine;

namespace AlphaLoot.Harmony
{

    public static class AlphaLootTools
    {
        private const string AUTOUPDATER_FILE = "AutoUpdater/do_not_edit_this_file.json";
        private static readonly string[] DefaultAddContainers = { "crate_normal", "loot-barrel-1", "loot-barrel-2", "box.wooden" };

        public class ItemListFile
        {
            [JsonProperty("itemIds")] public List<int> itemIds = new List<int>();
            [JsonProperty("protocol")] public string protocol;
        }

        public static void RunAutoUpdater(AlphaLootMod mod)
        {
            if (mod == null) return;
            string basePath = GetBasePath(mod);
            if (string.IsNullOrEmpty(basePath)) return;

            string path = Path.Combine(basePath, AUTOUPDATER_FILE);
            string dir = Path.GetDirectoryName(path);
            if (!string.IsNullOrEmpty(dir) && !Directory.Exists(dir))
                Directory.CreateDirectory(dir);

            ItemListFile lastList = null;
            if (File.Exists(path))
            {
                try
                {
                    lastList = JsonConvert.DeserializeObject<ItemListFile>(File.ReadAllText(path));
                }
                catch { }
            }

            if (lastList != null && lastList.protocol == Rust.Protocol.printable)
            {
                Debug.Log("[AlphaLoot Auto Updater] Protocol matches. No new items added.");
                return;
            }

            var currentIds = new List<int>();
            if (ItemManager.itemDictionary != null)
            {
                foreach (var k in ItemManager.itemDictionary.Keys)
                    currentIds.Add(k);
            }
            if (currentIds.Count == 0) return;

            if (lastList == null || lastList.itemIds == null)
            {
                lastList = new ItemListFile { itemIds = new List<int>(), protocol = "" };
            }

            var newItems = new List<int>();
            for (int i = 0; i < currentIds.Count; i++)
            {
                if (!lastList.itemIds.Contains(currentIds[i]))
                    newItems.Add(currentIds[i]);
            }
            if (newItems.Count > 0)
            {
                Debug.Log($"[AlphaLoot Auto Updater] Found {newItems.Count} new items. Adding to loot tables.");
                AddItemsToLootTable(mod, newItems, out int added);
                if (added > 0)
                {
                    SaveData(mod);
                    Debug.Log($"[AlphaLoot Auto Updater] Added {added} loot definitions.");
                }
            }

            File.WriteAllText(path, JsonConvert.SerializeObject(new ItemListFile
            {
                itemIds = currentIds,
                protocol = Rust.Protocol.printable
            }, Formatting.Indented));
        }

        public static void AddItems(ConsoleSystem.Arg arg, string[] shortnames, AlphaLootMod mod)
        {
            if (mod == null) { Reply(arg, "AlphaLoot mod not loaded."); return; }
            if (shortnames == null || shortnames.Length == 0)
            {
                Reply(arg, "al.additems <shortname> [shortname2] ... - Add item(s) to loot tables.");
                return;
            }

            var itemIds = new List<int>();
            foreach (var s in shortnames)
            {
                var def = ItemManager.FindItemDefinition(s);
                if (def != null) itemIds.Add(def.itemid);
            }

            if (itemIds.Count == 0)
            {
                Reply(arg, "No valid item shortnames found.");
                return;
            }

            AddItemsToLootTable(mod, itemIds, out int added);
            if (added > 0)
            {
                SaveData(mod);
                Reply(arg, $"Added {added} loot definitions for {itemIds.Count} items.");
            }
            else
                Reply(arg, "No matching containers found to add items to.");
        }

        public static void SearchItem(ConsoleSystem.Arg arg, string shortname, AlphaLootMod mod)
        {
            if (mod == null) { Reply(arg, "AlphaLoot mod not loaded."); return; }
            if (string.IsNullOrEmpty(shortname))
            {
                Reply(arg, "al.search <shortname> - Search which containers have this item.");
                return;
            }
            if (!ItemManager.itemDictionaryByName.ContainsKey(shortname))
            {
                Reply(arg, "Invalid item shortname.");
                return;
            }

            var results = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
            SearchInProfile(mod.StoredData, shortname, results);
            SearchInProfile(mod.HeliData, shortname, results);
            SearchInProfile(mod.BradleyData, shortname, results);

            if (results.Count == 0)
                Reply(arg, $"Item '{shortname}' not found in any loot profile.");
            else
            {
                var parts = new List<string>();
                foreach (var kv in results)
                    parts.Add($"{kv.Key}:{kv.Value}");
                Reply(arg, string.Join(", ", parts));
            }
        }

        private static void SearchInProfile(StoredData data, string shortname, Dictionary<string, int> results)
        {
            if (data == null) return;
            foreach (var kv in data.loot_advanced ?? new Dictionary<string, AdvancedLootContainerProfile>())
            {
                int c = 0;
                CountItemInSlots(kv.Value?.LootSpawnSlots, shortname, ref c);
                if (c > 0) results[kv.Key] = (results.TryGetValue(kv.Key, out var v) ? v : 0) + c;
            }
            foreach (var kv in data.loot_simple ?? new Dictionary<string, SimpleLootContainerProfile>())
            {
                int c = 0;
                CountItemInItems(kv.Value?.Items, shortname, ref c);
                if (c > 0) results[kv.Key] = (results.TryGetValue(kv.Key, out var v) ? v : 0) + c;
            }
            foreach (var kv in data.npcs_advanced ?? new Dictionary<string, AdvancedNPCLootProfile>())
            {
                int c = 0;
                CountItemInSlots(kv.Value?.LootSpawnSlots, shortname, ref c);
                if (c > 0) results[kv.Key] = (results.TryGetValue(kv.Key, out var v) ? v : 0) + c;
            }
            foreach (var kv in data.npcs_simple ?? new Dictionary<string, SimpleNPCLootProfile>())
            {
                int c = 0;
                CountItemInItems(kv.Value?.Items, shortname, ref c);
                if (c > 0) results[kv.Key] = (results.TryGetValue(kv.Key, out var v) ? v : 0) + c;
            }
        }

        private static void CountItemInSlots(LootSpawnSlot[] slots, string shortname, ref int count)
        {
            if (slots == null) return;
            foreach (var slot in slots)
                CountItemInLootSpawn(slot?.LootDefinition, shortname, ref count);
        }

        private static void CountItemInLootSpawn(LootSpawn spawn, string shortname, ref int count)
        {
            if (spawn == null) return;
            if (spawn.Items != null)
                foreach (var i in spawn.Items)
                    if (i?.Shortname == shortname) count++;
            if (spawn.SubSpawn != null)
                foreach (var e in spawn.SubSpawn)
                    CountItemInLootSpawn(e?.Category, shortname, ref count);
        }

        private static void CountItemInItems(ItemAmountSpawnsWith[] items, string shortname, ref int count)
        {
            if (items == null) return;
            foreach (var i in items)
                if (i?.Shortname == shortname) count++;
        }

        private static void AddItemsToLootTable(AlphaLootMod mod, List<int> itemIds, out int additions)
        {
            additions = 0;
            foreach (int itemId in itemIds)
            {
                if (!ItemManager.itemDictionary.TryGetValue(itemId, out var def) || def == null) continue;
                string shortname = def.shortname;

                foreach (var container in DefaultAddContainers)
                {
                    if (mod.StoredData?.loot_advanced?.TryGetValue(container, out var profile) == true)
                    {
                        if (AddItemToProfile(profile, shortname, container))
                            additions++;
                    }
                }
            }
        }

        private static bool AddItemToProfile(AdvancedLootContainerProfile profile, string shortname, string containerName)
        {
            if (profile?.LootSpawnSlots == null) return false;
            foreach (var slot in profile.LootSpawnSlots)
                if (SlotContainsItem(slot, shortname)) return false;

            var newSlot = new LootSpawnSlot
            {
                LootDefinition = new LootSpawn
                {
                    Items = new[] { new ItemAmountRanged { Shortname = shortname, MinAmount = 1, MaxAmount = 1 } },
                    SubSpawn = Array.Empty<LootSpawn.Entry>()
                },
                NumberToSpawn = 1,
                Probability = 0.01f
            };
            var list = new List<LootSpawnSlot>();
            if (profile.LootSpawnSlots != null)
                list.AddRange(profile.LootSpawnSlots);
            list.Add(newSlot);
            profile.LootSpawnSlots = list.ToArray();
            return true;
        }

        private static bool SlotContainsItem(LootSpawnSlot slot, string shortname)
        {
            return CountInSpawn(slot?.LootDefinition, shortname) > 0;
        }

        private static int CountInSpawn(LootSpawn spawn, string shortname)
        {
            if (spawn == null) return 0;
            int c = 0;
            if (spawn.Items != null)
                foreach (var i in spawn.Items)
                    if (i?.Shortname == shortname) c++;
            if (spawn.SubSpawn != null)
                foreach (var e in spawn.SubSpawn)
                    c += CountInSpawn(e?.Category, shortname);
            return c;
        }

        public static void SaveData(AlphaLootMod mod)
        {
            if (mod == null || mod.Config == null) return;
            string path = GetBasePath(mod);
            if (string.IsNullOrEmpty(path)) return;

            var dir = Path.Combine(path, "LootProfiles");
            TrySave(mod.StoredData, Path.Combine(dir, (mod.Config.ProfileName ?? "default_loottable") + ".json"));
            TrySave(mod.HeliData, Path.Combine(dir, (mod.Config.HeliProfileName ?? "default_heli_loottable") + ".json"));
            TrySave(mod.BradleyData, Path.Combine(dir, (mod.Config.BradleyProfileName ?? "default_bradley_loottable") + ".json"));
        }

        private static void TrySave(StoredData data, string path)
        {
            try
            {
                var dir = Path.GetDirectoryName(path);
                if (!string.IsNullOrEmpty(dir) && !Directory.Exists(dir))
                    Directory.CreateDirectory(dir);
                var settings = new JsonSerializerSettings { Formatting = Formatting.Indented, ReferenceLoopHandling = ReferenceLoopHandling.Ignore };
                File.WriteAllText(path, JsonConvert.SerializeObject(data ?? new StoredData(), settings));
            }
            catch (Exception ex) { Debug.LogError($"[AlphaLoot] Save error {path}: {ex.Message}"); }
        }

        private static string GetBasePath(AlphaLootMod mod) => mod?.BaseDataPath;

        private static void Reply(ConsoleSystem.Arg arg, string msg)
        {
            if (arg?.Connection != null)
                arg.ReplyWith(msg);
            else
                Debug.Log($"[AlphaLoot] {msg}");
        }
    }
}
